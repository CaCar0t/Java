public class TestIF1 {
    public static void main(String[] args) {
        int x = 50;
        int y = 10;

        if(x>y){
            System.out.println("Hello World");
        }
    }
}
